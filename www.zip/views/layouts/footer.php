<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="../../template/js/bootstrap.min.js"></script>
    </div>
</div>
<footer class="footer" style="height: 50px; margin-top: 10px">
</footer>
</body>
</html>

