<?php

return array(
    'host' => 'localhost',
    'dbname' => 'mtest',
    'user' => 'root',
    'password' => '',
);
